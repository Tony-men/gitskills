#include "MultiGame.h"

MultiGame::MultiGame()
{

}
